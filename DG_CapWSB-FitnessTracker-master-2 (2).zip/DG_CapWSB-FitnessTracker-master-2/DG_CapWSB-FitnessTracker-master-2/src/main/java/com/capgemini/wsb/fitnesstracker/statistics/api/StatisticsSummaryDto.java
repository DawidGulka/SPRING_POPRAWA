package com.capgemini.wsb.fitnesstracker.statistics.api;

public record StatisticsSummaryDto(Long id, Long userId, int totalTrainings, double totalDistance, int totalCaloriesBurned) {
}