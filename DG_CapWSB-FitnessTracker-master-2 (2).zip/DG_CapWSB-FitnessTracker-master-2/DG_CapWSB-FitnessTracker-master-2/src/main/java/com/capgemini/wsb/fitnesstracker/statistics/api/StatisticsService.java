package com.capgemini.wsb.fitnesstracker.statistics.api;

import java.util.List;

public interface StatisticsService {
    List<Statistics> findAllStatistics();
    Statistics createStatistics(Statistics statistics);
}