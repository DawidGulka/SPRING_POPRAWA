package com.capgemini.wsb.fitnesstracker.statistics.internal;

import com.capgemini.wsb.fitnesstracker.statistics.api.Statistics;
import com.capgemini.wsb.fitnesstracker.statistics.api.StatisticsDto;
import com.capgemini.wsb.fitnesstracker.statistics.api.StatisticsSummaryDto;
import com.capgemini.wsb.fitnesstracker.user.api.User;
import com.capgemini.wsb.fitnesstracker.user.api.UserProvider;
import org.springframework.stereotype.Component;

@Component
public class StatisticsMapper {

    private final UserProvider userProvider;

    public StatisticsMapper(UserProvider userProvider) {
        this.userProvider = userProvider;
    }

    public StatisticsSummaryDto toSummaryDto(Statistics statistics) {
        return new StatisticsSummaryDto(
                statistics.getId(),
                statistics.getUser().getId(),
                statistics.getTotalTrainings(),
                statistics.getTotalDistance(),
                statistics.getTotalCaloriesBurned()
        );
    }

    public Statistics toEntity(StatisticsDto statisticsDto) {
        User user = userProvider.getUser(statisticsDto.userId())
                .orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + statisticsDto.userId()));

        Statistics statistics = Statistics.create(user);
        statistics.setTotalTrainings(statisticsDto.totalTrainings());
        statistics.setTotalDistance(statisticsDto.totalDistance());
        statistics.setTotalCaloriesBurned(statisticsDto.totalCaloriesBurned());
        return statistics;
    }
}