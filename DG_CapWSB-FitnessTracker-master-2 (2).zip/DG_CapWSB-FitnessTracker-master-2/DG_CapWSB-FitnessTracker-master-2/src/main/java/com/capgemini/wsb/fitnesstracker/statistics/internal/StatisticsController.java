package com.capgemini.wsb.fitnesstracker.statistics.internal;

import com.capgemini.wsb.fitnesstracker.statistics.api.Statistics;
import com.capgemini.wsb.fitnesstracker.statistics.api.StatisticsDto;
import com.capgemini.wsb.fitnesstracker.statistics.api.StatisticsService;
import com.capgemini.wsb.fitnesstracker.statistics.api.StatisticsSummaryDto;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/statistics")
public class StatisticsController {

    private final StatisticsService statisticsService;
    private final StatisticsMapper statisticsMapper;

    public StatisticsController(StatisticsService statisticsService, StatisticsMapper statisticsMapper) {
        this.statisticsService = statisticsService;
        this.statisticsMapper = statisticsMapper;
    }

    @GetMapping
    public List<StatisticsSummaryDto> getAllStatisticsSummary() {
        return statisticsService.findAllStatistics()
                .stream()
                .map(statisticsMapper::toSummaryDto)
                .toList();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public StatisticsSummaryDto createStatistics(@RequestBody StatisticsDto statisticsDto) {
        Statistics statistics = statisticsMapper.toEntity(statisticsDto);
        Statistics createdStatistics = statisticsService.createStatistics(statistics);
        return statisticsMapper.toSummaryDto(createdStatistics);
    }
}