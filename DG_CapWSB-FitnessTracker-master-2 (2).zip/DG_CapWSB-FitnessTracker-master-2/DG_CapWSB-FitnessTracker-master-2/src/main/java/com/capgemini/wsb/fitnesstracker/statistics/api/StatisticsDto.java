package com.capgemini.wsb.fitnesstracker.statistics.api;

public record StatisticsDto(Long userId, int totalTrainings, double totalDistance, int totalCaloriesBurned) {
}